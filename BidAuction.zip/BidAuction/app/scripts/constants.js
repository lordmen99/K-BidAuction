(function() {
    'use strict';
     angular.module('bidAuctionApp').constant('kbconstants', {
        authServiceBaseUrl: '',
        serviceBaseUrl: 'http://localhost:9000/rest'
     });
})();
